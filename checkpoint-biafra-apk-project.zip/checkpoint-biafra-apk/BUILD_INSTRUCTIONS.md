# Checkpoint Biafra — Android APK & iOS Build Instructions

## Prerequisites
- Node.js 18+
- Android Studio (for APK)
- Xcode 15+ (for iOS .ipa)
- JDK 17+

## Quick Start

### 1. Install dependencies
```bash
npm install
```

### 2. Initialise Capacitor
```bash
npx cap init "Checkpoint Biafra" com.fiba.checkpointbiafra --web-dir www
```

### 3. Add Android platform
```bash
npx cap add android
npx cap sync android
```

### 4. Build the Android APK
```bash
# Open in Android Studio
npx cap open android

# OR build from command line (requires Android SDK):
cd android
./gradlew assembleDebug
# Output: android/app/build/outputs/apk/debug/app-debug.apk

# For release APK (requires signing keystore):
./gradlew assembleRelease
```

### 5. Add iOS platform (Mac only)
```bash
npx cap add ios
npx cap sync ios
npx cap open ios
# Build and archive in Xcode
```

## Signing the APK for release

### Generate a keystore
```bash
keytool -genkeypair -v \
  -keystore checkpoint-biafra.keystore \
  -alias checkpointbiafra \
  -keyalg RSA -keysize 2048 \
  -validity 10000
```

### Sign the APK
```bash
# In android/app/build.gradle, add signingConfigs block
# Then build: ./gradlew assembleRelease
```

## App Details
- Package ID: com.fiba.checkpointbiafra
- Min Android SDK: 22 (Android 5.1+)
- Target SDK: 34 (Android 14)
- Min iOS: 14.0
- Permissions required: INTERNET (for YouTube music only)

## Notes
- The game is fully offline-capable except for background music
- Music (AaRON — Maybe on the Moon) streams from YouTube
- All game logic, documents, and endings are self-contained
- Save data uses localStorage (persists between sessions)
